import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.interactions.Actions;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

public class RunTests extends TestHelper {


    // fb testuser
    private String username = "tompikk@yandex.com";
    private String password = "1Lollakas!";


    @Test
    public void pageNavigationNotLoggedInTest(){
        String expectedTitle = "Paremad Read - Avaleht";
        String actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement contactLink = driver.findElement(By.linkText("Kontakt"));
        contactLink.click();
        expectedTitle = "Paremad Read - Kontaktinfo";
        actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement statisticsLink = driver.findElement(By.linkText("Statistika"));
        statisticsLink.click();
        expectedTitle = "Paremad Read - Avaleht";
        actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        expectedTitle = "Paremad Read - Avaleht";
        actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);
    }

    @Test
    public void pageNavigationLoggedInTest(){
        login(username, password);

        String expectedTitle = "Paremad Read - Avaleht";
        String actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement contactLink = driver.findElement(By.linkText("Kontakt"));
        contactLink.click();
        expectedTitle = "Paremad Read - Kontaktinfo";
        actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement statisticsLink = driver.findElement(By.linkText("Statistika"));
        statisticsLink.click();
        expectedTitle = "Paremad Read - Statistika";
        actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        expectedTitle = "Paremad Read - Kasutaja seaded";
        actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle);

        WebElement indexLink = driver.findElement(By.linkText("Avaleht"));
        indexLink.click();
    }


    @Test
    public void loginLogoutTest(){
        login(username, password);
        WebElement loginStatus = driver.findElement(By.id("status"));
        assertTrue(loginStatus.getText().contains("Kasutaja on sisse logitud"));
        logout();
        wait2Seconds();
        String logoutStatus = driver.findElement(By.id("status")).getText();
        assertTrue(logoutStatus.contains("Kasutaja ei ole sisse logitud"));
    }


    @Test
    public void bankLinkTest(){

        login(username, password);
        WebElement contactLink = driver.findElement(By.linkText("Kontakt"));
        contactLink.click();
        wait2Seconds();
        WebElement bankLink = driver.findElement(By.id("donate"));
        try {
            bankLink.click();
            wait2Seconds();
        }
            catch (Exception e) {
        }
        String actualUrl = driver.getCurrentUrl();
        String expectedUrl = "http://localhost:3480/banklink/swedbank";
        assertEquals(expectedUrl, actualUrl);

    }


    @Test
    public void loginNameTest() throws Exception{

        login(username, password);
        waitForElementById("navbarStatistics");
        WebElement statisticsLink = driver.findElement(By.linkText("Statistika"));
        statisticsLink.click();

        waitForElementById("loggedInUsers");
        wait2Seconds();
        WebElement loggedInUsers = driver.findElement(By.tagName("pre"));
        while (loggedInUsers.getText().length() == 0) {
        }
        assertTrue(driver.getPageSource().contains("<pre id=\"loggedInUsers\">Toomas Pikk"));
        //logout();
    }

    @Test
    public void uploadAvatarNoFileSelectedTest() {
        login(username, password);
        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        WebElement upload = driver.findElement(By.name("submit"));
        upload.click();

        Alert alert = driver.switchTo().alert();
        assertEquals("Pole faili", alert.getText());
        alert.accept();
        driver.switchTo().defaultContent();

    }


    @Test
    public void uploadAvatarExistsTest() {
        login(username, password);
        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        WebElement element = driver.findElement(By.xpath("//input[@type='file']"));
        element.sendKeys(avatarUrl);
        WebElement upload = driver.findElement(By.name("submit"));
        upload.click();

        Alert alert = driver.switchTo().alert();
        alert.accept();
        alert = driver.switchTo().alert();
        alert.accept();

        driver.switchTo().defaultContent();

        waitForElementById("fileToUpload");
        element = driver.findElement(By.id("fileToUpload"));
        element.sendKeys(avatarUrl);
        upload = driver.findElement(By.name("submit"));
        upload.click();

        alert = driver.switchTo().alert();
        alert.accept();
        alert = driver.switchTo().alert();
        assertEquals("Fail juba eksisteerib.", alert.getText());
        alert.accept();
        driver.switchTo().defaultContent();

    }

    @Test
    public void uploadAvatarTest() {
        login(username, password);
        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        WebElement element = driver.findElement(By.xpath("//input[@type='file']"));
        element.sendKeys(avatarUrl);
        WebElement upload = driver.findElement(By.name("submit"));
        upload.click();

        Alert alert = driver.switchTo().alert();
        alert.accept();
        alert = driver.switchTo().alert();
        assertEquals("Fail 10900.jpg laeti üles.", alert.getText());
        alert.accept();

        String pageSource = driver.getPageSource();
        assertTrue(pageSource.contains("10900.jpg"));
        WebElement delete = driver.findElement(By.name("delete"));
        delete.click();
    }


    @Test
    public void deleteExistingAvatarTest() {
        login(username, password);

        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        WebElement element = driver.findElement(By.xpath("//input[@type='file']"));
        element.sendKeys(avatarUrl);
        WebElement upload = driver.findElement(By.name("submit"));
        upload.click();

        Alert alert = driver.switchTo().alert();
        alert.accept();
        alert = driver.switchTo().alert();
        alert.accept();

        WebElement delete = driver.findElement(By.name("delete"));
        delete.click();
        assertFalse(driver.getPageSource().contains("10900.jpg"));
    }


    @Test
    public void deleteNonExistingAvatarTest() {
        login(username, password);
        WebElement userLink = driver.findElement(By.linkText("Kasutaja"));
        userLink.click();
        WebElement delete = driver.findElement(By.name("delete"));
        delete.click();
        Alert alert = driver.switchTo().alert();
        assertEquals("Pole midagi kustutada.", alert.getText());
        alert.accept();
    }


    @Test
    public void languageSwitchTest() {
        login(username, password);

        WebElement element = driver.findElement(By.xpath("//img[@alt='in english']"));
        element.click();
        WebElement loginStatus = driver.findElement(By.id("status"));
        assertTrue(loginStatus.getText().contains("User is logged in"));

        element = driver.findElement(By.xpath("//img[@alt='eesti keeles']"));
        element.click();
        loginStatus = driver.findElement(By.id("status"));
        assertTrue(loginStatus.getText().contains("Kasutaja on sisse logitud"));
    }
}




