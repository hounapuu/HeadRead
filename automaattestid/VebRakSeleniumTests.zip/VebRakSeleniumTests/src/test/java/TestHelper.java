import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class TestHelper {

    static WebDriver driver;
    final int waitForResposeTime = 4;
    String baseUrl = "http://headread.ninata.ga/index.php";
    String avatarUrl = "C:\\Users\\Jubelugu\\Google Drive\\Informaatika tü\\Veebirakenduste loomine LTAT.05.004\\VebRakSeleniumTests\\10900.jpg";

    @Before
        public void setUp(){

        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Jubelugu\\Google Drive\\Informaatika tü\\Tarkvara testimine MTAT.03.159\\Lab5\\geckodriver.exe");
        driver = new FirefoxDriver();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(baseUrl);

    }



    void waitForElementById(String id){
        new WebDriverWait(driver, waitForResposeTime).until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
    }


    void login(String username, String password){

        driver.get(baseUrl);
        driver.findElement(By.id("loginButton")).click();
        driver.findElement(By.id("email")).sendKeys(username);
        driver.findElement(By.id("pass")).sendKeys(password);
        WebElement loginButton = driver.findElement(By.id("loginbutton"));
        loginButton.click();
    }

    void logout(){
        //waitForElementById("logoutButton");
        wait2Seconds();
        //driver.get(baseUrl);
        WebElement logout = driver.findElement(By.id("logoutButton"));
        logout.click();
    }

    public void wait2Seconds() {
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

    }

    @After
    public void tearDown(){
        driver.close();
    }

}